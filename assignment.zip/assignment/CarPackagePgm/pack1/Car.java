package pack1;

public abstract class Car {
	public int engine_cc;
	public abstract void baseCar();
}
