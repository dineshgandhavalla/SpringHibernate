package pack3;
import pack1.*;
import pack2.ChildCar;

public class Calling extends ChildCar{

	public static void main(String[] args) {
		
		ChildCar c =new ChildCar();
		c.baseCar();
		
			
		}
	}


