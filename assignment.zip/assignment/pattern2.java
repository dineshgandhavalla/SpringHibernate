package patternprograms;

public class pattern2 {

	public static void main(String[] args) {
		int i,j,n=5;
		for(i=n;i>=1;i--)
		{
			for(j=i;j>=1;j--)
			{
				System.out.print(j);
			}
		System.out.println();
		}
	}

}
